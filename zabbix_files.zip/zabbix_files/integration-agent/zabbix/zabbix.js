importPackage(java.lang);
importPackage(java.io);

importClass(Packages.org.apache.commons.httpclient.Header);
importClass(Packages.org.apache.commons.httpclient.HttpVersion);
importClass(Packages.org.mule.providers.http.HttpResponse);

load("integrationservices/zabbix/configuration.js");
load("lib/integrationservices/javascript/event.js");

var zabbixAuth = "notvalid";

var zabbixBody = {}
zabbixBody.userLogin = {
	"jsonrpc": "2.0",
	"method": "user.login",
	"params": {
		"user": ZABBIX_USER,
		"password": ZABBIX_PASSWORD
	},
	"id": 1,
	"auth": null
}

zabbixBody.eventAcknowledge = {
	"jsonrpc": "2.0",
	"method": "event.acknowledge",
	"params": {
		"eventids": null,
		"message": null,
		"action": 0
	},
	"id": 1,
	"auth": null
}

zabbixBody.hostGet = {
	"jsonrpc": "2.0",
	"method": "host.get",
	"params": {
		"output": [
			"hostid",
			"host"
		],
		"selectInterfaces": [
			"interfaceid",
			"ip"
		]
	},
	"id": 2,
	"auth": null
}

function zabbixPost(body) {
    IALOG.debug("ENTER zabbixPost: " + body.method);
	if (body == null) {
		IALOG.error("zabbixPost body is null");
		return null;
	}
    if (body.method != "user.login") {
        body.auth = zabbixAuth;
    }

    IALOG.debug('BODY: ' + JSON.stringify(body));
    resp = XMIO.post(JSON.stringify(body), ZABBIX_API_URL);

    IALOG.debug("Response status: " + resp.status);
    IALOG.debug("Response body: " + resp.body);

    if (resp.status < 200 || resp.status > 299) {
        IALOG.warn("Post to Zabbix failed. HTTP response code: " + resp.status);
        return null;
    }

    json = JSON.parse(resp.body);
    if (json.error != null) {
        IALOG.error("Zabbix returned error: " + json.error.data);
        if (json.error.data.indexOf("Session terminated") == -1) {
            return null;
        }

        IALOG.info("Zabbix: Need to log in again");
        resp = zabbixPost(zabbixBody.userLogin);
        if (resp == null) {
            return null;
        }
        zabbixAuth = resp.result;
        json = zabbixPost(body);
    }

    IALOG.debug("EXIT zabbixPost: " + body.method);
    return json;
}

function ackZabbixEvent(eventId, message) {
    IALOG.debug("ENTER ackZabbixEvent");

	body = zabbixBody.eventAcknowledge;
	body.params.eventids = eventId;
	body.params.message = message;
	zabbixPost(body);

    IALOG.debug("EXIT ackZabbixEvent");
}

function zabbixGetHost() {
    IALOG.debug("ENTER zabbixGetHost");

	body = zabbixBody.hostGet;
    zabbixPost(body);

    IALOG.debug("EXIT zabbixGetHost");
}

function apia_event(form)
{
    IALOG.debug("ENTER apia_event");

    // APClient.bin injection has been converted to a JavaScript object
    // that can be serialized and sent to xMatters.
    IALOG.debug(JSON.stringify(form, null, 2));
    IALOG.debug('Properties: JSON: ' + JSON.stringify( form.properties ));

    var recipients = form.recipients;
    if (recipients !== undefined) {
        form.recipients = [{"id":recipients}];
        IALOG.debug("recipients: " + recipients);
    }

    //Remove callbacks so that we can handle the settings as part
    // of outbound integrations
    delete form.callbacks;

    IALOG.debug("EXIT apia_event");
    return form;
}

function apia_callback(msg)
{
    IALOG.debug("ENTER apia_event");

    var str = "Received callback from xMatters:\n";
    str += "Incident: " + msg.incident_id;
    str += "\nEvent Id: " + msg.eventidentifier;
    str += "\nCallback Type: " + msg.xmatters_callback_type;
    str += "\nRAW: \n" + JSON.stringify( msg );
    IALOG.info(str);

    message = "Acknowledged by " + msg.recipient;
    if (msg.annotation != null && msg.annotation != "null") {
        message += "\nComments: " + msg.annotation;
    }

    ackZabbixEvent(msg.additionalTokens["EVENT.ID"], message);

    IALOG.debug("EXIT apia_event");
}

function apia_http(httpRequestProperties, httpResponse) {
    // First some debugging. State we are entering the
    // apia_http function. This helps sort out where
    // we are in the code.
    IALOG.error("Enter - apia_http");

    IALOG.error("Exit - apia_http");
}
