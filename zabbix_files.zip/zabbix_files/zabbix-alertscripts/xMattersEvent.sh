#!/bin/bash
IA_HOME=/opt/integrationagent-5.1.8.1

# pipe all output to log file
logfile=/var/log/xMattersEvent.log
exec >> $logfile 2>&1

echo ""
echo "-----------------------------------------------"
echo $(date)


target=$1
# split third argument into an array
readarray -t values <<<"$3"

# strip trailing carriage returns
for i in "${!values[@]}"; do
  values[$i]=`echo ${values[$i]} |tr -d '\r'`
done

set -x
$IA_HOME/bin/APClient.bin --map-data "applications|zabbix" "$target" "${values[@]}"
